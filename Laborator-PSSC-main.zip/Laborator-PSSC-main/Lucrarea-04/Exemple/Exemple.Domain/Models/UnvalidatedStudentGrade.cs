﻿namespace Exemple.Domain.Models
{
    public record UnvalidatedStudentGrade(string StudentRegistrationNumber, string ExamGrade, string ActivityGrade);
}
