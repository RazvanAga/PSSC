﻿namespace Exemple.Domain.Models
{
    public record UnvalidatedStudentGrade(string StudentRegistrationNumber, decimal ExamGrade, decimal ActivityGrade);
}
