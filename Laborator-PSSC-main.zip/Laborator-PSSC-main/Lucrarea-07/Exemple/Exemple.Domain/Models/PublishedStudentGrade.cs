﻿namespace Exemple.Domain.Models
{
    public record PublishedStudentGrade(StudentRegistrationNumber StudentRegistrationNumber, Grade ExamGrade, Grade ActivityGrade, Grade FinalGrade);
}
