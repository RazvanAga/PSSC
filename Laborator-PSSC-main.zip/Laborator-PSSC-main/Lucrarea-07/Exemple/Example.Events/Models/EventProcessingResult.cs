﻿namespace Example.Events.Models
{
    public enum EventProcessingResult
    {
        Completed,
        Retry,
        Failed
    }
}
