﻿namespace Exemple.Domain
{
    public record ValidatedStudentGrade(StudentRegistrationNumber StudentRegistrationNumber, Grade Grade);
}
