﻿namespace Exemple.Domain
{
    public record UnvalidatedStudentGrade(string StudentRegistrationNumber, string Grade);
}
