﻿namespace Example.Data.Models
{
    public class StudentDto
    {
        public int StudentId {  get; set; }
        public string Name { get; set; }
        public string RegistrationNumber { get; set; }
    }
}
